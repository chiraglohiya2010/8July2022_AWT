function c1()
{
document.getElementById("font").style.fontSize = "100px";
}
function c2()
{
    document.getElementById("font").style.color="purple";
}
function c3()
{
    document.getElementById("font2").style.fontStyle="Impact,Charcoal,sans-serif";
}